// vue.config.js 
module.exports = {
  devServer: {
    port: 8887,
    open: true
  }
}